var sine;
var freq = 200;
var capture;
let int;
let analyzer;
var vol;
let song;
function setup() {
	createCanvas(700, 440);
    capture = createCapture();
	capture.hide();
    mic = new p5.AudioIn();
	sine = new p5.SinOsc();
	sine.start();
    mic.start();
    song = loadSound('Here it Comes - TrackTribe.mp3');
}

function draw() {

	background(0);

	var hertz = map(mouseX, 20, width, 20.0, 440.0);

	sine.freq(hertz);

	stroke(204);

	for (var x = 0; x < width; x++) {

		var angle = map(x, 20, width, 20, TWO_PI * hertz);

		var sinValue = sin(angle) * 50;

		line(x, 0, x, height/12 + sinValue);
		
	}

   
    var aspectRatio = capture.height/capture.width/2;
	var h = width * aspectRatio;
	image(capture, 0, 90, width, h);
	filter(INVERT);
  	
  
    // Get the overall volume (between 0 and 1.0)
  let vol = mic.getLevel();
  fill(127);
  stroke(0);

  // Draw an ellipse with height based on volume
  let t = map(vol, 0, 1, height, 0);
  ellipse(width / 2, t - 25, 50, 50);

}  
 function mousePressed() {
  if (song.isPlaying()) {
    // .isPlaying() returns a boolean
    song.stop();
    background(255, 0, 0);
  } else {
    song.play();
    background(0, 255, 0);
  } 
  
}
