let img; // Declare variable 'img'.
let img2; // Declare variable 'img'.
let img3; // Declare variable 'img'.

function preload() {

  img = loadImage("autumn-leaves-royalty-free-image-1594753784.jpg");
  img2 = loadImage("37623-6-fall-autumn-leaves-transparent.png");
  img3 = loadImage("8Mefkm-autumn-leaves-decoration-background.png");
}
function setup() {
  createCanvas(2121, 1414);
  textFont("Arial");
  stroke(0);
}

function draw() {
  background(0);
    image(img, 0, 0);
    image(img2, 0, 0);
    image(img3, 130, 0, 120, 60);
textSize(150);
  fill(147);
  strokeWeight(4);
    text("BE FEARLESS IN THE", 300, 460);
    text("PURSUIT OF WHAT SETS", 200, 700);
  strokeWeight(5);
  fill(183, 119, 8);
    text("YOU SOUL ON FIRE!", 350, 960);
  
  image(img2, mouseX -img2.width / -600, mouseY - img2.height / -600);
  image(img3, mouseX - img3.width / 1, mouseY - img3.height / 1);
}