let vid1;
let vid2;
let vid3;
function setup() {
  createCanvas(700, 400);
    noCanvas();
   vid1 = createVideo( ['treeline.mp4'],
    
    vid1Load
  );
  vid2 = createVideo(['cute-kitten-on-white-background-extreme-close-up-meow-SBV-306398815-preview.mp4'],
    vid2Load     
  
  );
  vid3 = createVideo(['trees and sun.mp4'],
    vid3Load     
  
  );
  vid1.size(200, 200);
  vid2.size(200, 200);
  vid3.size(200, 200);
}
  
function vid1Load() {
  vid1.loop();
  vid1.volume(0);

}
function vid2Load() {
  vid2.loop();
  vid2.volume(0);
}
function vid3Load() {
  vid3.loop();
  vid3.volume(0);
}